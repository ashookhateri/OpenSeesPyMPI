"""Merge per-rank results and compare OpenSeesPyMPI against serial OpenSeesPy.

Usage:
    python compare_results.py                 # both linear and nonlinear
    python compare_results.py frame_linear
    python compare_results.py --rtol 1e-5 --atol 1e-9

Reads tests/results/<tag>.<module>.rank<N>.json produced by test_3/test_4, merges the
per-rank views into one global model answer (each rank only owns a subset of
nodes and elements after ops.partition()), then diffs against the serial run
(<tag>.opensees.rank0.json written with OPS_MODULE=opensees).

Output sections: displacements, support reactions, element forces, timing,
numerical differences, and a summary verdict per quantity.
"""

import argparse
import glob
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
RESULTS = os.environ.get("OPS_RESULTS_DIR", os.path.join(HERE, "results"))

SECTIONS = (
    ("displacements", "node displacements [ux, uy, rz]"),
    ("reactions", "support reactions [Fx, Fy, M]"),
    ("element_forces", "element end forces"),
)


def load_runs(tag):
    """Return {run_key: merged_payload} where run_key is 'serial' or 'mpi-n<N>'."""
    runs = {}
    for path in sorted(glob.glob(os.path.join(RESULTS, f"{tag}.*.rank*.json"))):
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
        module = data.get("module", "?")
        size = data.get("size", 1)
        key = "serial" if module == "opensees" and size == 1 else f"mpi-n{size}"
        run = runs.setdefault(key, {"module": module, "size": size, "ranks": []})
        run["ranks"].append(data)

    for key, run in runs.items():
        merged = {name: {} for name, _ in SECTIONS}
        timing = {}
        for rank_data in run["ranks"]:
            for name, _ in SECTIONS:
                for k, v in rank_data.get(name, {}).items():
                    if k in merged[name] and merged[name][k] != v:
                        print(f"WARNING [{key}] {name}[{k}] differs between ranks: "
                              f"{merged[name][k]} vs {v}")
                    merged[name][k] = v
            for k, v in (rank_data.get("timing") or {}).items():
                timing[k] = max(timing.get(k, 0.0), v)
            run.setdefault("systems", set()).add(rank_data.get("system", "?"))
            run.setdefault("owned", []).append(
                (rank_data.get("nodes_owned"), rank_data.get("elements_owned"))
            )
        run["merged"] = merged
        run["timing"] = timing
    return runs


def diff(a, b, rtol, atol):
    worst_abs, worst_rel, worst_key = 0.0, 0.0, None
    mismatched = 0
    for key in sorted(set(a) & set(b)):
        va, vb = a[key], b[key]
        if not isinstance(va, list) or not isinstance(vb, list):
            continue
        for i, (x, y) in enumerate(zip(va, vb)):
            abs_d = abs(x - y)
            rel_d = abs_d / max(abs(x), abs(y), 1e-30)
            if abs_d > worst_abs:
                worst_abs, worst_key = abs_d, f"{key}[{i}]"
            worst_rel = max(worst_rel, rel_d)
            if abs_d > atol + rtol * max(abs(x), abs(y)):
                mismatched += 1
    only_a = len(set(a) - set(b))
    only_b = len(set(b) - set(a))
    return {
        "worst_abs": worst_abs,
        "worst_rel": worst_rel,
        "worst_key": worst_key,
        "mismatched": mismatched,
        "missing": only_a + only_b,
    }


def report(tag, runs, rtol, atol):
    print(f"\n{'=' * 78}\n{tag}: {len(runs)} run(s) found in {RESULTS}\n{'=' * 78}")
    if not runs:
        print("  no results - run test_3/test_4 first")
        return 0

    for key, run in runs.items():
        print(f"  {key:<10} module={run['module']:<15} systems={sorted(run['systems'])} "
              f"owned(node,ele)={run['owned']}")
        if run["timing"]:
            print(f"             timing: " + ", ".join(f"{k}={v:.4f}s" for k, v in sorted(run["timing"].items())))

    serial = runs.get("serial")
    mpi_runs = {k: v for k, v in runs.items() if k != "serial"}
    if not serial:
        print("\n  NO SERIAL REFERENCE: run the same script with OPS_MODULE=opensees")
        return 0
    if not mpi_runs:
        print("\n  NO MPI RUN: launch with mpiexec -n 2 / -n 4")
        return 0

    failed = False
    for key, run in sorted(mpi_runs.items()):
        print(f"\n--- {key} vs serial ---")
        for name, label in SECTIONS:
            d = diff(serial["merged"][name], run["merged"][name], rtol, atol)
            status = "OK" if d["mismatched"] == 0 and d["missing"] == 0 else "DIFF"
            if status == "DIFF":
                failed = True
            print(f"  {label:<34} {status:<5} "
                  f"worst|Δ|={d['worst_abs']:.3e} ({d['worst_key']}) "
                  f"worst rel={d['worst_rel']:.3e} mismatched={d['mismatched']} "
                  f"missing={d['missing']}")

        t_ser = serial["timing"].get("analysis_s")
        t_par = run["timing"].get("analysis_s")
        if t_ser and t_par:
            print(f"  wall clock analysis: serial={t_ser:.4f}s {key}={t_par:.4f}s "
                  f"speedup={t_ser / t_par:.2f}x "
                  f"({'slower' if t_par > t_ser else 'faster'} for this model size)")

    print("\nVERDICT:", "numerical agreement within tolerance" if not failed else
          "differences exceed tolerance - inspect the sections marked DIFF")
    return 0 if not failed else 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("tags", nargs="*", default=["frame_linear", "frame_nonlinear"])
    ap.add_argument("--rtol", type=float, default=1e-6)
    ap.add_argument("--atol", type=float, default=1e-9)
    args = ap.parse_args()

    rc = 0
    for tag in args.tags:
        rc |= report(tag, load_runs(tag), args.rtol, args.atol)
    return rc


if __name__ == "__main__":
    sys.exit(main())
