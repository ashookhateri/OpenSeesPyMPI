"""Helpers shared by the OpenSeesPyMPI test suite.

The module under test is chosen by the OPS_MODULE environment variable so the
same scripts can be pointed at the serial OpenSeesPy build:

    OPS_MODULE=opensees       (default if import of opensees_mpi fails)
    OPS_MODULE=opensees_mpi

Nothing here calls MPI_Init / MPI_Finalize: the extension owns the MPI
lifecycle (see ARCHITECTURE.md, "Process ownership").
"""

import importlib
import json
import os
import sys
import time

SERIAL_MODULE = "opensees"
MPI_MODULE = "opensees_mpi"


def load_ops():
    """Import the OpenSees module under test."""
    name = os.environ.get("OPS_MODULE")
    if not name:
        try:
            importlib.import_module(MPI_MODULE)
            name = MPI_MODULE
        except ImportError:
            name = SERIAL_MODULE
    return importlib.import_module(name), name


def has_mpi(ops):
    """True when the loaded module exposes the MPI introspection API."""
    return hasattr(ops, "getMPIRank")


def rank(ops):
    return ops.getMPIRank() if has_mpi(ops) else 0


def size(ops):
    return ops.getMPISize() if has_mpi(ops) else 1


def barrier(ops):
    if has_mpi(ops):
        ops.mpiBarrier()


def parallel_sum(ops, value):
    """Sum a float over MPI_COMM_WORLD (returns the value when serial)."""
    if has_mpi(ops):
        return ops.mpiSum(float(value))
    return float(value)


def is_root(ops):
    return rank(ops) == 0


def log(ops, msg):
    """Print with rank prefix, flushed, so mpiexec output stays readable."""
    print(f"[rank {rank(ops)}/{size(ops)}] {msg}", flush=True)


def results_dir():
    d = os.environ.get("OPS_RESULTS_DIR") or os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "results"
    )
    os.makedirs(d, exist_ok=True)
    return d


def write_result(ops, tag, payload, module_name):
    """One JSON file per module per rank; merged later by compare_results.py.

    The module name is part of the filename on purpose: the serial run and the
    MPI run of the same script both have a rank 0, and they must not overwrite
    each other.
    """
    payload = dict(payload)
    payload.update(
        {
            "module": module_name,
            "rank": rank(ops),
            "size": size(ops),
            "timestamp": time.time(),
        }
    )
    path = os.path.join(results_dir(), f"{tag}.{module_name}.rank{rank(ops)}.json")
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2, sort_keys=True)
    return path


def safe_call(fn, *args, default=None):
    """Query something that may not exist on this rank after partitioning."""
    try:
        value = fn(*args)
        if value is None:
            return default
        return value
    except Exception as exc:  # noqa: BLE001 - OpenSees raises bare RuntimeError
        return {"error": str(exc)}


def close(a, b, rtol=1e-6, atol=1e-9):
    return abs(a - b) <= atol + rtol * max(abs(a), abs(b))


def require(cond, msg):
    if not cond:
        print(f"FAIL: {msg}", flush=True)
        sys.exit(1)
    print(f"ok   : {msg}", flush=True)
