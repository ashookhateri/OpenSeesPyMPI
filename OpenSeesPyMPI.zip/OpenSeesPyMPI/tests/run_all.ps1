<#
    Runs the OpenSeesPyMPI validation suite on Windows.

    Prerequisite: opensees.pyd (serial) and opensees_mpi.pyd (MPI) in -InstallDir.

        .\run_all.ps1 -InstallDir C:\OpenSeesPyMPI -Procs 2,4

    Every step's exit code is captured and reported; a failed step never stops
    the remaining ones, so one report contains the whole picture.
#>
[CmdletBinding()]
param(
    [string]   $InstallDir = '',
    [string]   $Python     = 'python',
    [int[]]    $Procs      = @(2, 4),
    [string]   $Mpiexec    = 'mpiexec'
)

$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot

if (-not $InstallDir) { $InstallDir = Split-Path $here -Parent }
$env:PYTHONPATH = $InstallDir
$env:OPS_RESULTS_DIR = Join-Path $here 'results'
New-Item -ItemType Directory -Force -Path $env:OPS_RESULTS_DIR | Out-Null

Write-Host "InstallDir : $InstallDir"
Write-Host "Python     : $(& $Python -c 'import sys;print(sys.executable)')"
Write-Host "mpiexec    : $((& $Mpiexec -help 2>&1 | Select-Object -First 1))"

$report = @()

function Invoke-Step([string] $name, [string[]] $argv, [hashtable] $envVars = @{}) {
    Write-Host "`n=== $name ===" -ForegroundColor Cyan
    $saved = @{}
    foreach ($k in $envVars.Keys) { $saved[$k] = [Environment]::GetEnvironmentVariable($k); Set-Item "env:$k" $envVars[$k] }
    $sw = [Diagnostics.Stopwatch]::StartNew()
    & $argv[0] @($argv[1..($argv.Length - 1)])
    $code = $LASTEXITCODE
    $sw.Stop()
    foreach ($k in $saved.Keys) { Set-Item "env:$k" $saved[$k] }
    $status = if ($code -eq 0) { 'PASS' } else { "EXIT $code" }
    Write-Host "$name -> $status ($([math]::Round($sw.Elapsed.TotalSeconds,2))s)" -ForegroundColor $(if ($code -eq 0) { 'Green' } else { 'Red' })
    $script:report += [pscustomobject]@{ Step = $name; Status = $status; Seconds = [math]::Round($sw.Elapsed.TotalSeconds, 2) }
}

# 0. artefacts present
$missing = @('opensees_mpi.pyd', 'opensees.pyd') | Where-Object { -not (Test-Path (Join-Path $InstallDir $_)) }
if ($missing) { Write-Host "WARNING: missing modules: $($missing -join ', ')" -ForegroundColor Yellow }

# 1. serial reference for the benchmark
Invoke-Step 'serial frame linear'    @($Python, (Join-Path $here 'test_3_frame_static.py'))    @{ OPS_MODULE = 'opensees' }
Invoke-Step 'serial frame nonlinear' @($Python, (Join-Path $here 'test_4_frame_nonlinear.py')) @{ OPS_MODULE = 'opensees' }

# 2. MPI lifecycle / communication / partition
Invoke-Step 'mpi lifecycle (n=1)'    @($Mpiexec, '-n', '1', $Python, (Join-Path $here 'test_1_lifecycle.py'))
foreach ($n in $Procs) {
    Invoke-Step "mpi lifecycle (n=$n)"     @($Mpiexec, '-n', "$n", $Python, (Join-Path $here 'test_1_lifecycle.py'))
    Invoke-Step "mpi communication (n=$n)" @($Mpiexec, '-n', "$n", $Python, (Join-Path $here 'test_2_communication.py'))
    Invoke-Step "mpi partition (n=$n)"     @($Mpiexec, '-n', "$n", $Python, (Join-Path $here 'test_5_partition.py'))
    Invoke-Step "mpi frame linear (n=$n)"     @($Mpiexec, '-n', "$n", $Python, (Join-Path $here 'test_3_frame_static.py'))
    Invoke-Step "mpi frame nonlinear (n=$n)"  @($Mpiexec, '-n', "$n", $Python, (Join-Path $here 'test_4_frame_nonlinear.py'))
}

# 3. comparison
Invoke-Step 'compare serial vs mpi' @($Python, (Join-Path $here 'compare_results.py'))

Write-Host "`n================ SUMMARY ================" -ForegroundColor Cyan
$report | Format-Table -AutoSize | Out-String | Write-Host
$report | Export-Csv -NoTypeInformation -Path (Join-Path $here 'results\summary.csv')
Write-Host "summary written to $(Join-Path $here 'results\summary.csv')"
