"""Test 3 - 2D steel frame, LINEAR static analysis, serial or MPI.

    # serial reference
    OPS_MODULE=opensees python test_3_frame_static.py

    # parallel, 2 then 4 processes
    mpiexec -n 2 python test_3_frame_static.py
    mpiexec -n 4 python test_3_frame_static.py

Environment:
    OPS_MODULE     opensees | opensees_mpi   (auto-detected)
    OPS_MPI_SOE    ParallelProfileSPD (default) | MPIDiagonal
    OPS_RESULTS_DIR  where per-rank JSON results are written

Each rank writes one JSON file; `compare_results.py` merges them and diffs
against the serial run. A successful mpiexec launch is NOT by itself evidence
of a parallel analysis - the comparison is what counts.
"""

import os
import sys
import time

import frame2d
import mpi_utils as u

ops, module_name = u.load_ops()
n = u.size(ops)
parallel = u.has_mpi(ops) and n > 1

u.log(ops, f"module={module_name} size={n} nonlinear=False")

t0 = time.time()
meta = frame2d.build(ops, nonlinear=False)

if parallel:
    u.log(ops, "partitioning the domain")
    rc = ops.partition()
    u.require(rc == 0, f"ops.partition() returned {rc}")
    u.barrier(ops)

    # each rank now holds a subset: the model metadata is shared, but queries
    # for foreign tags must be guarded (see frame2d.collect / safe_call)

system = "BandGeneral" if not parallel else os.environ.get("OPS_MPI_SOE", "ParallelProfileSPD")
u.log(ops, f"system = {system}")

t1 = time.time()
frame2d.analyse(ops, nonlinear=False, system=system, n_steps=1)
u.barrier(ops)
t_analysis = time.time() - t1

payload = frame2d.collect(ops, meta, u.safe_call)
payload["timing"] = {
    "build_s": round(t1 - t0, 6),
    "analysis_s": round(t_analysis, 6),
    "total_s": round(time.time() - t0, 6),
}
payload["system"] = system
payload["nodes_owned"] = len(ops.getNodeTags())
payload["elements_owned"] = len(ops.getElementTags())

# local headline result (only meaningful on ranks that own the node)
disp = u.safe_call(ops.nodeDisp, meta["control_node"])
u.log(ops, f"nodeDisp(control={meta['control_node']}) = {disp}")
u.log(ops, f"analysis time {t_analysis:.4f} s, owns {payload['elements_owned']} elements")

if not isinstance(disp, dict) and disp is not None:
    # gravity dominates: the vertical displacement at the control node must be negative
    if disp[1] > 0:
        print(f"WARNING: vertical displacement at control node is positive ({disp[1]})", flush=True)

path = u.write_result(ops, "frame_linear", payload, module_name)
u.log(ops, f"wrote {path}")

u.barrier(ops)
print("FRAME LINEAR: analysed (compare with compare_results.py)", flush=True)
sys.exit(0)
