# Test suite

Run order matters: the serial run must exist before the comparison.

Build first (`../build-linux.sh` or `..\build-windows.ps1`), then:

```bash
export PYTHONPATH=/path/to/build/install      # contains opensees.* and opensees_mpi.*

# 1. serial reference (standard OpenSeesPy)
OPS_MODULE=opensees python test_3_frame_static.py
OPS_MODULE=opensees python test_4_frame_nonlinear.py

# 2. MPI lifecycle / communication / partition
mpiexec -n 1 python test_1_lifecycle.py
mpiexec -n 2 python test_1_lifecycle.py
mpiexec -n 2 python test_2_communication.py
mpiexec -n 2 python test_5_partition.py

# 3. the structural benchmark
mpiexec -n 2 python test_3_frame_static.py
mpiexec -n 4 python test_3_frame_static.py
mpiexec -n 2 python test_4_frame_nonlinear.py
mpiexec -n 4 python test_4_frame_nonlinear.py

# 4. merge and compare
python compare_results.py
```

Windows:

```powershell
.\run_all.ps1 -InstallDir C:\OpenSeesPyMPI -Procs 2,4
```

## Files

| File | Purpose |
|---|---|
| `mpi_utils.py` | module selection (`OPS_MODULE`), rank/size helpers, per-rank JSON writer |
| `frame2d.py` | the 3-bay x 2-storey steel frame (linear and Steel02-fibre variants) and result collection |
| `test_1_lifecycle.py` | MPI init, rank/size consistency, unique ranks, clean shutdown |
| `test_2_communication.py` | Allreduce sums, repeated barriers, barrier actually synchronises |
| `test_5_partition.py` | `ops.partition()`: conservation, disjointness, non-empty parts, post-partition analysis |
| `test_3_frame_static.py` | linear static analysis, serial or MPI, writes per-rank JSON |
| `test_4_frame_nonlinear.py` | nonlinear static (Steel02, 10 Newton increments) |
| `test_6_lifecycle_safety.py` | `isMPIFinalized`, idempotent re-import, collectives still usable |
| `compare_results.py` | merges per-rank views and diffs against serial; exits 1 on divergence |
| `run_all.ps1` | runs everything on Windows and writes `results\summary.csv` |

## Deliberate-failure check for `mpiAbort()`

`mpiAbort()` terminates the whole job by design, so it is never part of the
passing suite. To confirm it behaves as an abort (nonzero exit, all ranks die
within the timeout), run this on purpose:

```bash
mpiexec -n 2 python -c "import opensees_mpi as o; o.mpiAbort(7)"
echo $?          # expect 7 (or another nonzero code), and the job to end at once
```

If that command hangs instead of ending, the lifecycle layer is not doing its
job and every other MPI result becomes suspect.

## Conventions

- Every result is written per rank as `results/<tag>.<module>.rank<N>.json`, so
  the serial and MPI runs never overwrite each other.
- A rank only queries nodes and elements it owns; `mpi_utils.safe_call` turns a
  foreign-tag failure into a skipped entry instead of an abort.
- `mpiexec` exiting 0 proves nothing about the analysis: only
  `compare_results.py` decides pass/fail.
- `OPS_MPI_SOE` selects the parallel solver: `ParallelProfileSPD` (default) or
  `MPIDiagonal`.
