"""Test 4 - 2D steel frame, NONLINEAR static analysis (Steel02 fibre section).

    OPS_MODULE=opensees   python test_4_frame_nonlinear.py        # reference
    mpiexec -n 2 python test_4_frame_nonlinear.py
    mpiexec -n 4 python test_4_frame_nonlinear.py

The load is applied in 10 increments with Newton-Raphson, so convergence (not
just startup) is part of the test.

Note: a *distributed* Newton-Raphson only exists in OpenSees through the
distributed SOE / DomainDecompositionAnalysis machinery. The Python layer can
select `ParallelProfileSPD` / `MPIDiagonal` for the linear solve, but the
residual and convergence loop stay per-rank; expect the nonlinear MPI path to
either agree with serial or to fail explicitly. Either outcome is reported -
never silently treated as success.
"""

import os
import sys
import time

import frame2d
import mpi_utils as u

ops, module_name = u.load_ops()
n = u.size(ops)
parallel = u.has_mpi(ops) and n > 1
u.log(ops, f"module={module_name} size={n} nonlinear=True")

meta = frame2d.build(ops, nonlinear=True)

if parallel:
    rc = ops.partition()
    u.require(rc == 0, f"ops.partition() returned {rc}")
    u.barrier(ops)

system = "BandGeneral" if not parallel else os.environ.get("OPS_MPI_SOE", "ParallelProfileSPD")

t0 = time.time()
failed_steps = 0
try:
    frame2d.analyse(ops, nonlinear=True, system=system, n_steps=10)
except Exception as exc:  # noqa: BLE001
    failed_steps = -1
    u.log(ops, f"NONLINEAR ANALYSIS FAILED: {exc}")
t_analysis = time.time() - t0

u.barrier(ops)

payload = frame2d.collect(ops, meta, u.safe_call)
payload["timing"] = {"analysis_s": round(t_analysis, 6)}
payload["system"] = system
payload["nonlinear"] = True
payload["analysis_ok"] = failed_steps == 0
payload["nodes_owned"] = len(ops.getNodeTags())
payload["elements_owned"] = len(ops.getElementTags())

u.log(ops, f"analysis_ok={payload['analysis_ok']} time={t_analysis:.4f}s")
path = u.write_result(ops, "frame_nonlinear", payload, module_name)
u.log(ops, f"wrote {path}")

if failed_steps != 0:
    print("FRAME NONLINEAR: FAILED on at least one rank (details above)", flush=True)
    sys.exit(2)

print("FRAME NONLINEAR: analysed (compare with compare_results.py)", flush=True)
sys.exit(0)
