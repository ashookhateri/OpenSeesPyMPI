"""Test 1 - MPI initialization and shutdown.

Checks, on every rank:
  * the module imports and reports an initialized communicator
  * rank / size are self-consistent
  * all ranks agree on `size` (via MPI_Allreduce)
  * the process exits cleanly (exit code 0) so Py_AtExit -> MPI_Finalize runs

Run:
    mpiexec -n 2 python test_1_lifecycle.py
    mpiexec -n 4 python test_1_lifecycle.py
"""

import sys

import mpi_utils as u

ops, module_name = u.load_ops()
u.log(ops, f"module under test: {module_name}")

if not u.has_mpi(ops):
    print("SKIP: the loaded module has no MPI API (serial OpenSeesPy build).", flush=True)
    sys.exit(0)

u.log(ops, f"isMPIInitialized = {ops.isMPIInitialized()}")
u.require(ops.isMPIInitialized() is True, "MPI is initialized after import")

r, n = ops.getMPIRank(), ops.getMPISize()
u.require(0 <= r < n, f"rank {r} is inside [0, {n})")

# all ranks must see the same communicator size
total = u.parallel_sum(ops, 1.0)
u.require(int(round(total)) == n, f"MPI_Allreduce counted {int(round(total))} processes, expected {n}")

# ranks must be distinct: sum(1..n) == n(n+1)/2
rank_sum = u.parallel_sum(ops, r + 1.0)
expected = n * (n + 1) / 2.0
u.require(u.close(rank_sum, expected), f"rank ids are unique (sum {rank_sum} == {expected})")

u.barrier(ops)
u.log(ops, "barrier reached on all ranks; exiting")
print("LIFECYCLE: PASS", flush=True)
sys.exit(0)
