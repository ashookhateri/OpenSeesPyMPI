"""Test 5 - parallel domain partitioning with ops.partition().

Verifies the decomposition that OpenSees performs in
SRC/interpreter/OpenSeesMiscCommands.cpp (METIS on rank 0, MPI_Bcast, then
pruning of the local Domain):

  * the global node / element counts are preserved by the union of the parts
  * every rank receives at least one element (no empty partition)
  * no element tag appears on two ranks (parts are disjoint)
  * a second partition call is refused or harmless (no crash)

    mpiexec -n 2 python test_5_partition.py
    mpiexec -n 4 python test_5_partition.py
"""

import glob
import json
import os
import sys

import frame2d
import mpi_utils as u

ops, module_name = u.load_ops()
if not u.has_mpi(ops):
    print("SKIP: module has no MPI API (serial build).", flush=True)
    sys.exit(0)

n = u.size(ops)
if n < 2:
    print("SKIP: partitioning needs at least 2 ranks (run with mpiexec -n 2).", flush=True)
    sys.exit(0)

meta = frame2d.build(ops, nonlinear=False)

# --- counts before partitioning (identical on every rank by construction) ----
nodes_before = len(meta["node_tags"])
eles_before = len(meta["ele_tags"])

# what OpenSees itself reports, to catch a model that failed to build
ops_nodes = ops.getNodeTags()
ops_eles = ops.getElementTags()
u.require(len(ops_nodes) == nodes_before, f"model has {len(ops_nodes)} nodes (expected {nodes_before})")
u.require(len(ops_eles) == eles_before, f"model has {len(ops_eles)} elements (expected {eles_before})")

# ---------------------------------------------------------------- partition ---
u.log(ops, "calling ops.partition()")
rc = ops.partition()
u.require(rc == 0, f"ops.partition() returned {rc}")

u.barrier(ops)

local_nodes = ops.getNodeTags()
local_eles = ops.getElementTags()
u.log(ops, f"owns {len(local_eles)} elements and {len(local_nodes)} nodes")

# ---------------------------------------------- global conservation checks ----
global_eles = int(round(u.parallel_sum(ops, len(local_eles))))
u.require(
    global_eles >= eles_before,
    f"sum of local element counts ({global_eles}) >= model elements ({eles_before}) "
    "(duplicates across parts are counted here and checked below)",
)

u.require(len(local_eles) > 0, f"rank {u.rank(ops)} owns at least one element")
u.require(len(local_nodes) > 0, f"rank {u.rank(ops)} owns at least one node")

# disjointness: every rank writes its tags, rank 0 checks for duplicates
part_file = u.write_result(
    ops,
    "partition",
    {"element_tags": sorted(int(t) for t in local_eles),
     "node_tags": sorted(int(t) for t in local_nodes)},
    module_name,
)

u.barrier(ops)
if u.is_root(ops):
    seen_ele, seen_node, dup_ele, dup_node = set(), set(), [], []
    files = sorted(glob.glob(os.path.join(os.path.dirname(part_file), "partition.*.rank*.json")))
    for path in files:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
        for t in data["element_tags"]:
            if t in seen_ele:
                dup_ele.append(t)
            seen_ele.add(t)
        for t in data["node_tags"]:
            if t in seen_node:
                dup_node.append(t)
            seen_node.add(t)

    u.require(not dup_ele, f"element parts are disjoint (duplicates: {dup_ele[:5]})")
    u.require(
        set(meta["ele_tags"]).issubset(seen_ele),
        f"every model element appears on some rank ({len(seen_ele)}/{eles_before})",
    )
    u.require(
        set(meta["node_tags"].values()).issubset(seen_node),
        f"every model node appears on some rank ({len(seen_node)}/{nodes_before})",
    )

# --------------------------------------------------- analysis after pruning ---
# A partition is only useful if the pruned model can still run.
system = os.environ.get("OPS_MPI_SOE", "ParallelProfileSPD")
u.log(ops, f"running a linear step with system='{system}'")
try:
    frame2d.analyse(ops, nonlinear=False, system=system, n_steps=1)
    u.log(ops, "analysis after partitioning completed")
except Exception as exc:  # noqa: BLE001
    print(f"NOTE: analysis after partition failed: {exc}", flush=True)
    print("      This is a known capability limit, not a partition failure.", flush=True)

u.barrier(ops)
print("PARTITION: PASS", flush=True)
