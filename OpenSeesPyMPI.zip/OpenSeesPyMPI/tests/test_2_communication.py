"""Test 2 - MPI communication (collective reduce, barrier, ordering).

    mpiexec -n 2 python test_2_communication.py
    mpiexec -n 4 python test_2_communication.py

Only uses the wrappers that the extension exposes; no mpi4py is required.
"""

import time

import mpi_utils as u

ops, module_name = u.load_ops()
if not u.has_mpi(ops):
    print("SKIP: module has no MPI API (serial build).", flush=True)
    raise SystemExit(0)

r, n = u.rank(ops), u.size(ops)
u.log(ops, f"module={module_name} rank={r} size={n}")

# 1. Allreduce sum of a rank-dependent value
value = 1.0 / (r + 1)
total = ops.mpiSum(value)
expected = sum(1.0 / (k + 1) for k in range(n))
u.require(u.close(total, expected), f"MPI_Allreduce sum {total:.12g} == {expected:.12g}")

# 2. Allreduce of a large value must not saturate / truncate
big = ops.mpiSum(1.0e6)
u.require(u.close(big, 1.0e6 * n), f"Allreduce of 1e6 over {n} ranks = {big:.6g}")

# 3. Barrier must not deadlock and must be repeatable
t0 = time.time()
for _ in range(5):
    ops.mpiBarrier()
u.log(ops, f"5 barriers completed in {time.time() - t0:.4f}s")

# 4. Barrier really synchronises: no rank may finish the last phase early
ops.mpiBarrier()
t1 = time.time()
if r == 0:
    time.sleep(0.2)          # rank 0 deliberately lags
ops.mpiBarrier()
waited = time.time() - t1
u.require(waited >= 0.15, f"barrier waited for the slow rank ({waited:.3f}s >= 0.15s)")

# 5. A late arrival must still be able to reduce
late = ops.mpiSum(0.0 if r != 0 else 1.0)
u.require(u.close(late, 1.0), f"Allreduce after barrier = {late}")

print("COMMUNICATION: PASS", flush=True)
