"""2D steel frame benchmark used by the OpenSeesPyMPI test suite.

Model: 3 bays x 2 storeys, 4.0 m bays, 3.0 m storeys, steel IPE-like section.
- linear  : elasticBeamColumn + Elastic section
- nonlinear: forceBeamColumn + fibre section with Steel02 (Giuffre-Menegotto-Pinto)

Both variants are deliberately small (12 elements, 12 nodes) so that a
2- or 4-process run finishes in seconds and so that any numerical difference
cannot hide in rounding noise.

The function is deterministic: every MPI rank builds exactly the same model,
which `ops.partition()` requires (it verifies mesh equality with MPI_Reduce).
"""

BAYS = 3
STOREYS = 2
BAY = 4.0
STOREY = 3.0

E = 2.0e11          # Pa
NU = 0.3
G = E / (2.0 * (1.0 + NU))
A = 7.68e-3         # m^2  (IPE 300-ish)
IZ = 8.356e-5       # m^4
J = 2.0e-4          # m^4
RHO = 7850.0

FY = 2.35e8         # Pa
B_HARD = 0.02


def build(ops, nonlinear=False):
    """Build the frame and return metadata used by the tests."""
    ops.wipe()
    ops.model("basic", "-ndm", 2, "-ndf", 3)

    # ---------------------------------------------------------------- materials
    if nonlinear:
        ops.uniaxialMaterial("Steel02", 1, FY, E, B_HARD, 18.0, 0.925, 0.15)
        ops.section("Fiber", 1, "-GJ", G * J)
        d, b = 0.30, 0.19
        ops.patch("rect", 1, 6, 4, -d / 2.0, -b / 2.0, d / 2.0, b / 2.0)
        ops.beamIntegration("Lobatto", 1, 1, 5)
    else:
        ops.section("Elastic", 1, E, A, IZ, G, J)

    # ------------------------------------------------------------------- nodes
    node_tags = {}
    tag = 0
    for j in range(STOREYS + 1):
        for i in range(BAYS + 1):
            tag += 1
            ops.node(tag, i * BAY, 1.0e-12 * j)  # 1e-12 avoids exact coincident y=0
            node_tags[(i, j)] = tag

    base = [node_tags[(i, 0)] for i in range(BAYS + 1)]
    for n in base:
        ops.fix(n, 1, 1, 0)

    # ---------------------------------------------------------------- elements
    ops.geomTransf("Linear", 1)
    ele_tags = []
    etag = 0
    for j in range(STOREYS + 1):
        for i in range(BAYS + 1):
            if i < BAYS:  # beams
                etag += 1
                ele_tags.append(etag)
                if nonlinear:
                    ops.element("forceBeamColumn", etag, node_tags[(i, j)],
                                node_tags[(i + 1, j)], 1, 1)
                else:
                    ops.element("elasticBeamColumn", etag, node_tags[(i, j)],
                                node_tags[(i + 1, j)], A, E, IZ, 1)
    for j in range(STOREYS):
        for i in range(BAYS + 1):
            etag += 1  # columns
            ele_tags.append(etag)
            if nonlinear:
                ops.element("forceBeamColumn", etag, node_tags[(i, j)],
                            node_tags[(i, j + 1)], 1, 1)
            else:
                ops.element("elasticBeamColumn", etag, node_tags[(i, j)],
                            node_tags[(i, j + 1)], A, E, IZ, 1)

    ops.fix(node_tags[(0, 0)], 1, 1, 0)

    # ------------------------------------------------------- loads (1 pattern)
    ops.timeSeries("Linear", 1)
    ops.pattern("Plain", 1, 1)

    w_grav = -25.0e3  # N per node (downward)
    for j in range(1, STOREYS + 1):
        for i in range(BAYS + 1):
            ops.load(node_tags[(i, j)], 0.0, w_grav, 0.0)

    p_lat = 40.0e3  # N at roof level, left column
    ops.load(node_tags[(0, STOREYS)], p_lat, 0.0, 0.0)

    return {
        "node_tags": node_tags,
        "base_nodes": base,
        "ele_tags": ele_tags,
        "roof_node": node_tags[(0, STOREYS)],
        "control_node": node_tags[(BAYS, STOREYS)],
    }


def analyse(ops, nonlinear=False, system="BandGeneral", n_steps=1):
    """Run one static analysis. `system` is the SOE name passed to ops.system()."""
    ops.constraints("Transformation")
    ops.numberer("RCM")
    ops.system(system)
    if nonlinear:
        ops.test("NormDispIncr", 1.0e-8, 20, 0)
        ops.algorithm("Newton")
        ops.integrator("LoadControl", 1.0 / n_steps)
        ops.analysis("Static")
        for step in range(n_steps):
            ok = ops.analyze(1)
            if ok != 0:
                raise RuntimeError(f"nonlinear step {step} failed (analyze returned {ok})")
    else:
        ops.test("NormDispIncr", 1.0e-10, 10, 0)
        ops.algorithm("Linear")
        ops.integrator("LoadControl", 1.0)
        ops.analysis("Static")
        ok = ops.analyze(1)
        if ok != 0:
            raise RuntimeError(f"linear analysis failed (analyze returned {ok})")


def collect(ops, meta, safe_call):
    """Collect displacements, reactions and element forces that exist locally."""
    disp = {}
    for key, tag in meta["node_tags"].items():
        value = safe_call(ops.nodeDisp, tag)
        if isinstance(value, dict):
            continue
        disp[f"{key[0]}_{key[1]}"] = [float(v) for v in value]

    reac = {}
    for key, tag in meta["node_tags"].items():
        if key[1] != 0:
            continue
        value = safe_call(ops.nodeReaction, tag)
        if isinstance(value, dict):
            continue
        reac[key[0]] = [float(v) for v in value]

    forces = {}
    for et in meta["ele_tags"]:
        value = safe_call(ops.eleResponse, et, "localForce")
        if isinstance(value, dict) or value is None:
            continue
        forces[str(et)] = [float(v) for v in value]

    return {"displacements": disp, "reactions": reac, "element_forces": forces}
