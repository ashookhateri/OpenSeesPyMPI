"""Test 6 - MPI lifecycle safety surface.

    mpiexec -n 1 python test_6_lifecycle_safety.py
    mpiexec -n 2 python test_6_lifecycle_safety.py

Checks the state machine that the P1 remediation added around the broker
(see TECHNICAL_AUDIT.md D8):

  * MPI is initialized after import and NOT finalized while the module is alive
  * isMPIFinalized() reports False consistently on every rank
  * a second import of the same module object is harmless (no re-initialization)
  * the process exits 0, i.e. Py_AtExit -> ~OpenSeesCommands ->
    ~MPI_MachineBroker finalized exactly once, without aborting

mpiAbort() is intentionally NOT called here: it terminates the whole job by
design. It is exercised only by a manual, expected-to-fail run described in
tests/README.md.

STATUS: NOT RUN in the delivery environment (no MPI, module cannot be built).
"""

import sys

import mpi_utils as u

ops, module_name = u.load_ops()
if not u.has_mpi(ops):
    print("SKIP: module has no MPI API (serial build).", flush=True)
    sys.exit(0)

u.log(ops, f"module={module_name}")

u.require(ops.isMPIInitialized() is True, "MPI initialized after import")
u.require(ops.isMPIFinalized() is False, "MPI not finalized while the module is alive")

# A second import must not initialize MPI again (idempotent module import).
import importlib  # noqa: E402

again = importlib.import_module(module_name)
u.require(again is ops or again.__name__ == module_name, "re-import returns the same module")
u.require(again.isMPIInitialized() is True, "MPI still initialized after re-import")
u.require(again.isMPIFinalized() is False, "MPI still not finalized after re-import")

# Rank/size must survive the re-import unchanged.
r1, n1 = ops.getMPIRank(), ops.getMPISize()
r2, n2 = again.getMPIRank(), again.getMPISize()
u.require((r1, n1) == (r2, n2), f"rank/size stable across re-import ({r1},{n1}) == ({r2},{n2})")

# The collective surface must still be usable here (barrier + reduce).
u.barrier(ops)
u.require(u.close(u.parallel_sum(ops, 2.0), 2.0 * n1), "collective still functional")

# Finalization must not have happened behind our back.
u.require(ops.isMPIFinalized() is False, "still not finalized before exit")

u.log(ops, "exiting normally; finalization is verified by the process exit code")
print("LIFECYCLE SAFETY: PASS", flush=True)
sys.exit(0)
