#==============================================================================
#
#        OpenSees -- Open System For Earthquake Engineering Simulation
#                Pacific Earthquake Engineering Research Center
#
#     (c) Copyright 1999-2026 The Regents of the University of California
#                             All Rights Reserved
#
#==============================================================================
#
# ops_py_module_suffix(<outvar>)
#
# Returns the file suffix a CPython extension module must have on the platform
# being configured.
#
# Why this exists: the upstream install rule used ${CMAKE_SHARED_MODULE_SUFFIX},
# which is ".dll" on Windows -- CMake's CMakeSystemSpecificInformation.cmake
# simply copies CMAKE_SHARED_LIBRARY_SUFFIX into it when the platform does not
# override it, and Platform/Windows.cmake sets that to ".dll".  A CPython
# extension on Windows must be ".pyd", otherwise `import <name>` cannot find it.
#
# The function is a separate file so that both branches can be unit-tested with
# `cmake -P` on any host (see tests in the delivery package).
#
function(ops_py_module_suffix outvar)

    set(_ops_suffix "")

    if(WIN32)
        # MSVC, clang-cl and MinGW: CPython only imports "*.pyd".
        set(_ops_suffix ".pyd")
    elseif(DEFINED Python_SOABI AND
           NOT "${Python_SOABI}" STREQUAL "" AND
           NOT "${Python_SOABI}" STREQUAL "None")
        # CPython >= 3.2: opensees_mpi.cpython-312-x86_64-linux-gnu.so
        set(_ops_suffix ".${Python_SOABI}${CMAKE_SHARED_MODULE_SUFFIX}")
    else()
        # Plain .so is importable as well and is what upstream used.
        set(_ops_suffix "${CMAKE_SHARED_MODULE_SUFFIX}")
    endif()

    set(${outvar} "${_ops_suffix}" PARENT_SCOPE)

endfunction()
